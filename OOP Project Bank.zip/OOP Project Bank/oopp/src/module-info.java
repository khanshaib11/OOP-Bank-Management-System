/**
 * 
 */
/**
 * @author mjava
 *
 */
module oopp {
	requires java.desktop;
}